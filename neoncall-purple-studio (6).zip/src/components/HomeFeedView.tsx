import React, { useState, useRef, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Video,
  PhoneCall,
  Sparkles,
  CheckCircle2,
  Music2,
  Music,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Send,
  Coins,
  Crown,
  Radio,
  Plus,
  Download,
  Film,
  DollarSign,
  Flame
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PostItem, StoryItem, UserProfile } from '../types';
import { AdMobBanner } from './AdMobBanner';
import { StoryCreatorModal } from './StoryCreatorModal';
import { MusicSelectorModal } from './MusicSelectorModal';
import { MUSIC_CATALOG, MusicTrackItem } from '../data/musicTracks';
import { LuckySpinBanner } from './LuckySpinBanner';
import { ShakeAndWinBanner } from './ShakeAndWinBanner';

interface HomeFeedViewProps {
  currentUser: UserProfile | null;
  onStartCall: (roomId: string, targetUser?: string) => void;
  onOpenAuth: () => void;
  onNavigateToSearch: () => void;
  onCreateNewPost: () => void;
  onOpenAICreator?: () => void;
  onOpenVideoReels?: () => void;
  onOpenLuckySpin?: () => void;
  onOpenShakeAndWin?: () => void;
  posts: PostItem[];
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
}

export const HomeFeedView: React.FC<HomeFeedViewProps> = ({
  currentUser,
  onStartCall,
  onOpenAuth,
  onNavigateToSearch,
  onCreateNewPost,
  onOpenAICreator,
  onOpenVideoReels,
  onOpenLuckySpin,
  onOpenShakeAndWin,
  posts,
  onToggleLike,
  onAddComment,
}) => {
  const [activeStory, setActiveStory] = useState<StoryItem | null>(null);
  const [isStoryCreatorOpen, setIsStoryCreatorOpen] = useState<boolean>(false);
  const [isMusicModalOpen, setIsMusicModalOpen] = useState<boolean>(false);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [openCommentsModalPostId, setOpenCommentsModalPostId] = useState<string | null>(null);
  const [savedPostIds, setSavedPostIds] = useState<Set<string>>(new Set());
  const [watchedEarningsToast, setWatchedEarningsToast] = useState<{ amount: string; coins: number } | null>(null);
  const [watchedPostMap, setWatchedPostMap] = useState<Record<string, boolean>>({});
  const [videoPlayingState, setVideoPlayingState] = useState<Record<string, boolean>>({
    'post-1': true,
  });
  const [videoMutedState, setVideoMutedState] = useState<Record<string, boolean>>({
    'post-1': true,
  });

  // Story Audio Playback controller
  const [isStoryAudioPlaying, setIsStoryAudioPlaying] = useState<boolean>(true);
  const storyAudioRef = useRef<HTMLAudioElement | null>(null);

  // Dynamic user stories list with preloaded Hindi, Slowed, English, Naat tracks
  const [storyList, setStoryList] = useState<StoryItem[]>([
    {
      id: 'story-self',
      userId: currentUser?.id || 'usr-naushad',
      userName: currentUser?.name || 'Your Story',
      userUsername: currentUser?.username || 'naushad',
      userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      isVerified: currentUser?.isVerified ?? true,
      hasUnseenStory: false,
      mediaUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
      caption: 'Live streaming from Neon Studio 💜',
      musicTrackTitle: 'Apna Bana Le',
      musicTrackArtist: 'Arijit Singh',
      musicTrackAudioUrl: 'https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3',
      musicCategory: 'hindi',
      adMobEarnings: '+$0.35 AdMob',
    },
    {
      id: 'story-1',
      userId: 'usr-elena',
      userName: 'Elena Vance',
      userUsername: 'elena_neon',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      isVerified: true,
      hasUnseenStory: true,
      mediaUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800&auto=format&fit=crop&q=80',
      caption: 'Direct Dialing @naushad in 4K Opus Studio! 🚀',
      musicTrackTitle: 'Kahani Suno 2.0 (Slowed + Reverb)',
      musicTrackArtist: 'Kaifi Khalil',
      musicTrackAudioUrl: 'https://assets.mixkit.co/music/preview/mixkit-deep-urban-623.mp3',
      musicCategory: 'slowed',
      adMobEarnings: '+$0.50 AdMob',
    },
    {
      id: 'story-2',
      userId: 'usr-marcus',
      userName: 'Dr. Marcus Lee',
      userUsername: 'marcus_ai',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      isVerified: true,
      hasUnseenStory: true,
      mediaUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
      caption: 'WebRTC ultra low-latency nodes synced worldwide 📡',
      musicTrackTitle: 'Starboy (Cyber Neon Mix)',
      musicTrackArtist: 'The Weeknd',
      musicTrackAudioUrl: 'https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3',
      musicCategory: 'english',
      adMobEarnings: '+$0.48 AdMob',
    },
    {
      id: 'story-3',
      userId: 'usr-sophia',
      userName: 'Sophia Chen',
      userUsername: 'sophia_vr',
      userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      isVerified: true,
      hasUnseenStory: true,
      mediaUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
      caption: 'Cyberpunk aesthetic drops tonight at 8 PM 🔮',
      musicTrackTitle: 'Chaleya (Jawan Hit)',
      musicTrackArtist: 'Arijit Singh & Shilpa Rao',
      musicTrackAudioUrl: 'https://assets.mixkit.co/music/preview/mixkit-holliday-690.mp3',
      musicCategory: 'hindi',
      adMobEarnings: '+$0.40 AdMob',
    },
    {
      id: 'story-4',
      userId: 'usr-devon',
      userName: 'Devon Miles',
      userUsername: 'devon_sound',
      userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      isVerified: false,
      hasUnseenStory: true,
      mediaUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80',
      caption: 'Tajdar-e-Haram Soulful acoustic vibes 🕌',
      musicTrackTitle: 'Tajdar-e-Haram (Acoustic Soul)',
      musicTrackArtist: 'Atif Aslam',
      musicTrackAudioUrl: 'https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3',
      musicCategory: 'naat',
      adMobEarnings: '+$0.65 AdMob',
    },
  ]);

  // Handle active story music playback & AdMob revenue credit
  useEffect(() => {
    if (activeStory && activeStory.musicTrackAudioUrl) {
      if (storyAudioRef.current) {
        storyAudioRef.current.pause();
      }
      const audio = new Audio(activeStory.musicTrackAudioUrl);
      storyAudioRef.current = audio;
      audio.loop = true;
      audio.play().catch(() => {});
      setIsStoryAudioPlaying(true);

      // Reward creator & founder AdMob revenue for viewing a story with music
      setWatchedEarningsToast({
        amount: activeStory.adMobEarnings || '+$0.35 AdMob',
        coins: 5,
      });
      confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
      const timer = setTimeout(() => setWatchedEarningsToast(null), 3500);

      return () => {
        audio.pause();
        clearTimeout(timer);
      };
    } else {
      if (storyAudioRef.current) {
        storyAudioRef.current.pause();
      }
    }
  }, [activeStory]);

  const handleToggleStoryAudio = () => {
    if (!storyAudioRef.current) return;
    if (isStoryAudioPlaying) {
      storyAudioRef.current.pause();
      setIsStoryAudioPlaying(false);
    } else {
      storyAudioRef.current.play().catch(() => {});
      setIsStoryAudioPlaying(true);
    }
  };

  const handleAddStory = (newStory: StoryItem) => {
    setStoryList((prev) => [newStory, ...prev]);
    setActiveStory(newStory);
  };

  const handleLike = (postId: string) => {
    onToggleLike(postId);
    const post = posts.find((p) => p.id === postId);
    if (post && !post.isLiked) {
      confetti({
        particleCount: 25,
        spread: 45,
        origin: { y: 0.7 },
        colors: ['#ec4899', '#d946ef', '#a855f7'],
      });
    }
  };

  const handleSavePost = (postId: string) => {
    setSavedPostIds((prev) => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
      } else {
        next.add(postId);
      }
      return next;
    });
  };

  const handleSendComment = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;
    onAddComment(postId, text);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  return (
    <div id="instagrand-home-feed" className="max-w-xl mx-auto space-y-6 pb-20 animate-fade-in">
      {/* Top Stories Bar & Add Music Story Trigger */}
      <div className="p-3.5 rounded-3xl bg-zinc-950/90 border border-purple-900/50 shadow-xl overflow-hidden space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5 text-xs font-black text-white">
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>Instagrand Music Stories</span>
          </div>
          <button
            type="button"
            onClick={() => setIsMusicModalOpen(true)}
            className="text-[11px] font-bold text-fuchsia-400 hover:text-fuchsia-300 flex items-center gap-1 bg-purple-950/60 px-2 py-0.5 rounded-lg border border-purple-800/40"
          >
            <Music className="w-3 h-3 text-amber-300 animate-bounce" />
            <span>Music Catalog ({MUSIC_CATALOG.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1 px-1">
          {/* Add story for current user */}
          <div
            className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group"
            onClick={() => setIsStoryCreatorOpen(true)}
          >
            <div className="relative">
              <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-tr from-purple-700 via-zinc-800 to-zinc-900 border border-purple-500/30 group-hover:scale-105 transition-all">
                <img
                  src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                  alt="Your story"
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-purple-600 to-fuchsia-500 border-2 border-zinc-950 flex items-center justify-center text-white shadow-md">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </div>
            <span className="text-[11px] text-zinc-300 font-medium truncate w-16 text-center">
              + Story
            </span>
          </div>

          {/* Other creator stories */}
          {storyList.slice(1).map((story) => (
            <div
              key={story.id}
              onClick={() => setActiveStory(story)}
              className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group"
            >
              <div className="w-16 h-16 rounded-full p-[2.5px] bg-gradient-to-tr from-purple-500 via-fuchsia-500 to-cyan-400 group-hover:scale-105 transition-all shadow-[0_0_12px_rgba(217,70,239,0.35)]">
                <div className="w-full h-full rounded-full p-0.5 bg-zinc-950 relative">
                  <img
                    src={story.userAvatar}
                    alt={story.userName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                  {story.musicTrackTitle && (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-fuchsia-600 text-white flex items-center justify-center text-[8px] border border-zinc-950">
                      ♫
                    </div>
                  )}
                </div>
              </div>
              <span className="text-[11px] text-zinc-300 font-medium truncate w-16 text-center">
                @{story.userUsername}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Lucky Spin & Win Banner */}
      {onOpenLuckySpin && (
        <LuckySpinBanner
          onOpenLuckySpin={onOpenLuckySpin}
          currentUser={currentUser}
        />
      )}

      {/* Hindi, Slowed, English & Naat Sharif Music Discovery & Earning Banner */}
      <div
        id="music-story-discovery-banner"
        className="p-4 rounded-3xl bg-gradient-to-r from-fuchsia-950/80 via-zinc-950 to-amber-950/80 border-2 border-fuchsia-500/60 shadow-[0_0_35px_rgba(217,70,239,0.25)] space-y-3 relative overflow-hidden"
      >
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-fuchsia-500 to-pink-500 p-0.5 shadow-md shadow-fuchsia-500/30">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <Music className="w-5 h-5 text-amber-300 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-white">Music & Naat Sharif Story Studio</h3>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  AdMob Earning Boost
                </span>
              </div>
              <p className="text-[11px] text-purple-300/90">
                Hindi New · Slowed+Reverb · English Hits · Soulful Naat Sharif (Auto Monetized)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="open-music-catalog-btn"
              onClick={() => setIsMusicModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-purple-500/40 text-xs font-bold text-white flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Music className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Listen Songs</span>
            </button>

            <button
              type="button"
              id="create-music-story-btn"
              onClick={() => setIsStoryCreatorOpen(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-black text-xs flex items-center gap-1.5 transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Story with Music</span>
            </button>
          </div>
        </div>
      </div>

      {/* AI Creator Studio Assistant Launch Banner */}
      <div
        id="ai-creator-launch-banner"
        className="p-4 rounded-3xl bg-gradient-to-r from-purple-950/90 via-zinc-950 to-pink-950/90 border-2 border-fuchsia-500/60 shadow-[0_0_35px_rgba(217,70,239,0.3)] space-y-3 relative overflow-hidden"
      >
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-amber-400 p-0.5 shadow-md shadow-fuchsia-500/30">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-amber-300 animate-bounce" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-white">AI Photo & Video Assistant</h3>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  Earn Real Money
                </span>
              </div>
              <p className="text-[11px] text-purple-300">
                Generate 4K AI Art & Reels · Monetize automatically on every view
              </p>
            </div>
          </div>

          <button
            type="button"
            id="open-ai-creator-assistant-btn"
            onClick={onOpenAICreator}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer"
          >
            <span>Create AI Media</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
          </button>
        </div>
      </div>

      {/* 5 Video Option Showcase & 2 Private Files Download Launch Card */}
      <div
        id="video-5-clips-reels-banner"
        className="p-4 rounded-3xl bg-gradient-to-r from-cyan-950/80 via-zinc-950 to-purple-950/90 border-2 border-cyan-400/60 shadow-[0_0_35px_rgba(6,182,212,0.25)] space-y-3 relative overflow-hidden"
      >
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-teal-500 to-emerald-400 p-0.5 shadow-md shadow-cyan-500/30">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <Film className="w-5 h-5 text-cyan-300 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-white">5 High-Definition Video Theater</h3>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40">
                  5 Clips + 2 Private Downloads
                </span>
              </div>
              <p className="text-[11px] text-cyan-300/80">
                Browse 5 active 4K clips, watch founder reels, and download dual master files
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="open-video-5-clips-modal-btn"
              onClick={onOpenVideoReels}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-black font-black text-xs flex items-center justify-center gap-1.5 transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer"
            >
              <Film className="w-3.5 h-3.5" />
              <span>Watch 5 Videos</span>
              <Download className="w-3.5 h-3.5 ml-0.5 text-zinc-900" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Watch-to-Earn Video Monetization Toast */}
      {watchedEarningsToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-zinc-950 border-2 border-emerald-400 shadow-[0_0_30px_rgba(0,255,102,0.4)] flex items-center gap-2.5 text-xs text-white font-bold animate-bounce">
          <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400">
            <Coins className="w-3.5 h-3.5" />
          </div>
          <div>
            <span>Watch Reward: <strong className="text-emerald-300">{watchedEarningsToast.amount}</strong> + <strong className="text-amber-300">{watchedEarningsToast.coins} Coins</strong>!</span>
            <div className="text-[10px] text-zinc-400 font-normal">Credited to Creator & Founder AdMob Pool</div>
          </div>
        </div>
      )}

      {/* Posts Feed Stream */}
      <div className="space-y-6">
        {posts.map((post) => {
          const isSaved = savedPostIds.has(post.id);
          const isPlaying = videoPlayingState[post.id] ?? true;
          const isMuted = videoMutedState[post.id] ?? true;

          return (
            <article
              key={post.id}
              id={`post-card-${post.id}`}
              className="rounded-3xl bg-zinc-950/90 border border-purple-900/50 shadow-2xl overflow-hidden hover:border-purple-500/40 transition-all"
            >
              {/* Post Header */}
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-purple-500/40 shadow-sm"
                    />
                    {post.isVerified && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-fuchsia-600 border border-zinc-950 flex items-center justify-center shadow-[0_0_6px_#d946ef]">
                        <Crown className="w-2.5 h-2.5 text-amber-300" />
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-white hover:text-fuchsia-300 cursor-pointer">
                        {post.authorName}
                      </span>
                      <span className="text-xs text-purple-300/70 font-mono">
                        @{post.authorUsername}
                      </span>
                    </div>

                    {post.location && (
                      <span className="text-[11px] text-zinc-400 flex items-center gap-1">
                        <span>📍 {post.location}</span>
                        {post.audioTrack && (
                          <>
                            <span>•</span>
                            <span className="text-cyan-300 flex items-center gap-0.5">
                              <Music2 className="w-2.5 h-2.5" /> {post.audioTrack}
                            </span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                </div>

                {/* Direct Studio Call CTA & 3-dots */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onStartCall(`studio-${post.authorUsername}`, post.authorUsername)}
                    className="px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-600/30 to-fuchsia-600/30 border border-purple-500/50 hover:bg-purple-600/50 text-fuchsia-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <Video className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
                    <span>Call Live</span>
                  </button>

                  <button
                    type="button"
                    className="p-1.5 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Media Player Container */}
              <div className="relative w-full aspect-square bg-zinc-900 overflow-hidden flex items-center justify-center">
                {post.mediaType === 'video' ? (
                  <div className="relative w-full h-full">
                    <video
                      src={post.mediaUrl}
                      autoPlay
                      loop
                      muted={isMuted}
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-3 right-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setVideoMutedState((prev) => ({ ...prev, [post.id]: !isMuted }))
                        }
                        className="p-2 rounded-full bg-zinc-950/70 backdrop-blur-md text-white border border-purple-500/30 hover:bg-zinc-900 transition-all cursor-pointer"
                      >
                        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-fuchsia-400" />}
                      </button>
                    </div>

                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-purple-950/80 backdrop-blur-md border border-purple-500/40 text-[10px] font-bold text-fuchsia-300 flex items-center gap-1">
                      <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
                      <span>4K ULTRA HD OPUS</span>
                    </div>
                  </div>
                ) : (
                  <img
                    src={post.mediaUrl}
                    alt={post.caption}
                    className="w-full h-full object-cover"
                  />
                )}

                {post.isMonetized && (
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-amber-500/20 backdrop-blur-md border border-amber-500/50 text-[10px] font-bold text-amber-300 flex items-center gap-1 shadow-md">
                    <Coins className="w-3 h-3 text-amber-400" />
                    <span>Monetized · {post.earningsEst || 'Est. $18.40'}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons Row */}
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button
                      type="button"
                      onClick={() => handleLike(post.id)}
                      className="group flex items-center gap-1.5 text-zinc-300 hover:text-pink-400 transition-all cursor-pointer"
                    >
                      <Heart
                        className={`w-6 h-6 transition-transform group-active:scale-125 ${
                          post.isLiked
                            ? 'fill-pink-500 text-pink-500 shadow-[0_0_12px_#ec4899]'
                            : 'stroke-[2px]'
                        }`}
                      />
                      <span className="text-xs font-bold font-mono text-zinc-300">
                        {post.likesCount.toLocaleString()}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setOpenCommentsModalPostId(post.id)}
                      className="group flex items-center gap-1.5 text-zinc-300 hover:text-fuchsia-400 transition-all cursor-pointer"
                    >
                      <MessageCircle className="w-6 h-6 stroke-[2px] group-active:scale-110" />
                      <span className="text-xs font-bold font-mono text-zinc-300">
                        {post.commentsCount.toLocaleString()}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText?.(window.location.href);
                        confetti({ particleCount: 15, spread: 30 });
                      }}
                      className="text-zinc-300 hover:text-cyan-400 transition-all cursor-pointer"
                    >
                      <Share2 className="w-5 h-5 stroke-[2px]" />
                    </button>

                    {/* Download Master Video / 2 Private Files Trigger */}
                    <button
                      type="button"
                      onClick={onOpenVideoReels}
                      title="Download 2 Private Files & Watch 5 Videos"
                      className="flex items-center gap-1 text-xs font-mono font-bold text-zinc-300 hover:text-emerald-400 transition-all cursor-pointer bg-zinc-900/80 px-2 py-1 rounded-lg border border-purple-900/50 hover:border-emerald-500/50"
                    >
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span className="hidden sm:inline">2 Files</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onOpenVideoReels}
                      className="text-[11px] font-bold text-cyan-300 hover:text-cyan-200 flex items-center gap-1 bg-cyan-950/60 px-2.5 py-1 rounded-xl border border-cyan-500/40 hover:scale-105 transition-all cursor-pointer"
                    >
                      <Film className="w-3.5 h-3.5" />
                      <span>5 Videos</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSavePost(post.id)}
                      className="text-zinc-300 hover:text-amber-400 transition-all cursor-pointer p-1"
                    >
                      <Bookmark
                        className={`w-5 h-5 stroke-[2px] ${
                          isSaved ? 'fill-amber-400 text-amber-400' : ''
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Caption & Hashtags */}
                <div className="space-y-1.5 text-xs sm:text-sm">
                  <p className="text-zinc-200 leading-relaxed">
                    <span className="font-bold text-white mr-2 hover:text-fuchsia-300 cursor-pointer">
                      @{post.authorUsername}
                    </span>
                    {post.caption}
                  </p>

                  <div className="flex flex-wrap gap-1.5 text-[11px] font-mono text-purple-400">
                    {post.hashtags.map((tag, idx) => (
                      <span key={idx} className="hover:underline cursor-pointer">
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* AI Full Quality Verification & Payout Badge */}
                  <div className="pt-1 flex items-center justify-between text-[10px] font-mono border-t border-purple-950/60">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>{post.aiScanVerdict || `AI Quality Approved · ${post.aiQualityScore || 98}% Ultra HD`}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bold">
                      ₹{post.aiPayoutRupees ? post.aiPayoutRupees.toFixed(2) : (post.mediaType === 'video' ? '5.00' : '2.00')} Paid
                    </span>
                  </div>
                </div>

                {/* Inline comments snippet */}
                {post.comments.length > 0 && (
                  <div className="pt-2 border-t border-purple-900/40 space-y-1 text-xs">
                    {post.comments.slice(-2).map((comment) => (
                      <div key={comment.id} className="flex items-center gap-2">
                        <span className="font-bold text-zinc-300">@{comment.authorUsername}</span>
                        <span className="text-zinc-400 truncate">{comment.text}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Quick Add Comment Box */}
                <div className="pt-2 flex items-center gap-2">
                  <input
                    type="text"
                    placeholder={`Add a comment for @${post.authorUsername}...`}
                    value={commentInputs[post.id] || ''}
                    onChange={(e) =>
                      setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSendComment(post.id);
                    }}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-900/80 border border-purple-900/60 focus:border-fuchsia-500 focus:outline-none text-xs text-white placeholder-zinc-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleSendComment(post.id)}
                    className="p-2 rounded-xl bg-purple-600 hover:bg-fuchsia-600 text-white transition-all cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      {/* Official Google AdMob Sticky Banner Component */}
      <AdMobBanner position="sticky-bottom" />

      {/* Story View Modal with Live Music & AdMob Monetization */}
      {activeStory && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => {
            if (storyAudioRef.current) storyAudioRef.current.pause();
            setActiveStory(null);
          }}
        >
          <div
            className="relative w-full max-w-sm h-[80vh] rounded-3xl overflow-hidden border-2 border-purple-500/60 neon-border-purple bg-zinc-950 shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Story progress timer bar */}
            <div className="absolute top-3 left-3 right-3 z-20 flex gap-1">
              <div className="flex-1 h-1.5 rounded-full bg-white/25 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-purple-400 via-fuchsia-400 to-amber-300 w-full animate-pulse" />
              </div>
            </div>

            {/* Header info & audio toggle */}
            <div className="absolute top-6 left-4 right-4 z-20 flex items-center justify-between text-white">
              <div className="flex items-center gap-2">
                <img
                  src={activeStory.userAvatar}
                  alt={activeStory.userName}
                  className="w-8 h-8 rounded-full object-cover border border-purple-400 ring-1 ring-fuchsia-400"
                />
                <div>
                  <div className="text-xs font-bold flex items-center gap-1">
                    <span>{activeStory.userName}</span>
                    {activeStory.isVerified && <Crown className="w-3 h-3 text-amber-300" />}
                  </div>
                  <div className="text-[10px] text-purple-300 font-mono">@{activeStory.userUsername}</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activeStory.musicTrackAudioUrl && (
                  <button
                    type="button"
                    onClick={handleToggleStoryAudio}
                    className="p-1.5 rounded-full bg-zinc-950/80 border border-fuchsia-500/50 text-fuchsia-300 hover:text-white"
                  >
                    {isStoryAudioPlaying ? (
                      <Volume2 className="w-4 h-4 animate-pulse text-emerald-400" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-zinc-400" />
                    )}
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    if (storyAudioRef.current) storyAudioRef.current.pause();
                    setActiveStory(null);
                  }}
                  className="p-1.5 rounded-full bg-zinc-950/80 text-xs font-bold hover:bg-zinc-800 text-white"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Attached Music Pill on Active Story */}
            {activeStory.musicTrackTitle && (
              <div className="absolute top-18 left-4 right-4 z-20 p-2.5 rounded-2xl bg-zinc-950/85 backdrop-blur-md border border-fuchsia-500/60 flex items-center justify-between shadow-xl">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-fuchsia-600 flex items-center justify-center text-white flex-shrink-0">
                    <Music className="w-3.5 h-3.5 animate-bounce" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-black text-white truncate">
                      {activeStory.musicTrackTitle}
                    </div>
                    <div className="text-[10px] text-purple-300 truncate">
                      {activeStory.musicTrackArtist}
                    </div>
                  </div>
                </div>

                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  {activeStory.adMobEarnings || '+$0.35 AdMob'}
                </span>
              </div>
            )}

            <img
              src={activeStory.mediaUrl}
              alt="Story content"
              className="w-full h-full object-cover"
            />

            {/* Bottom Caption & AdMob Revenue Meter */}
            <div className="absolute bottom-4 left-4 right-4 z-20 space-y-2">
              {activeStory.caption && (
                <div className="p-3 rounded-2xl bg-zinc-950/85 backdrop-blur-md border border-purple-500/40 text-xs text-white text-center shadow-lg">
                  {activeStory.caption}
                </div>
              )}

              <div className="p-2 rounded-xl bg-gradient-to-r from-amber-950/90 via-zinc-950 to-purple-950/90 border border-amber-500/40 flex items-center justify-between text-[10px] font-mono text-zinc-300">
                <div className="flex items-center gap-1.5 text-amber-300">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Founder & Creator AdMob Share</span>
                </div>
                <span className="text-emerald-400 font-bold">100% Monetized</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Story Creator Modal */}
      <StoryCreatorModal
        isOpen={isStoryCreatorOpen}
        onClose={() => setIsStoryCreatorOpen(false)}
        currentUser={currentUser}
        onStoryPublished={handleAddStory}
      />

      {/* Music Selector & Audio Catalog Modal */}
      <MusicSelectorModal
        isOpen={isMusicModalOpen}
        onClose={() => setIsMusicModalOpen(false)}
        onSelectTrack={(track) => {
          setIsStoryCreatorOpen(true);
        }}
      />
    </div>
  );
};
